package com.example.memorymatchgame;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GameActivity extends AppCompatActivity {
    private GridView gridView;
    private TextView scoreText, timerText;
    private List<Card> cards;
    private CardAdapter cardAdapter;
    private int firstSelectedIndex = -1;
    private int score = 0;
    private boolean isChecking = false;
    private boolean gameStarted = false;
    private CountDownTimer countDownTimer;
    private int pairsMatched = 0;
    private final int totalPairs = 6;
    private boolean gameOver = false;

    private final int[] imageIds = {
            R.drawable.image1, R.drawable.image1,
            R.drawable.image2, R.drawable.image2,
            R.drawable.image3, R.drawable.image3,
            R.drawable.image4, R.drawable.image4,
            R.drawable.image5, R.drawable.image5,
            R.drawable.image6, R.drawable.image6
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Apply background for the game page
        getWindow().getDecorView().setBackgroundResource(R.drawable.background_game);

        // Initialize UI components
        gridView = findViewById(R.id.gridView);
        scoreText = findViewById(R.id.scoreText);
        timerText = findViewById(R.id.timerText);

        startGame(); // Start the game automatically
    }


    private void startGame() {
        // Reset game values
        score = 0;
        pairsMatched = 0;
        gameOver = false;
        scoreText.setText("Score: 0");
        timerText.setText("Time: 60s"); // Reset timer display
        gameStarted = true;

        // Start countdown timer
        if (countDownTimer != null) countDownTimer.cancel();
        countDownTimer = new CountDownTimer(60000, 1000) { // 60 seconds
            public void onTick(long millisUntilFinished) {
                timerText.setText("Time: " + millisUntilFinished / 1000 + "s");
            }

            public void onFinish() {
                gameStarted = false;
                timerText.setText("Time: 0s");
                if (pairsMatched < totalPairs) {
                    endGame(false); // Lose if all pairs are not matched
                }
            }
        }.start();

        initializeGame();
    }

    private void initializeGame() {
        cards = new ArrayList<>();
        for (int imageId : imageIds) {
            cards.add(new Card(imageId));
        }
        Collections.shuffle(cards);
        cardAdapter = new CardAdapter(this, cards);
        gridView.setAdapter(cardAdapter);

        gridView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            if (!gameStarted || isChecking || cards.get(position).isFlipped()) return;

            cards.get(position).setFlipped(true);
            cardAdapter.notifyDataSetChanged();

            if (firstSelectedIndex == -1) {
                firstSelectedIndex = position;
            } else {
                isChecking = true;
                new Handler().postDelayed(() -> checkMatch(position), 1000);
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void checkMatch(int secondSelectedIndex) {
        Card firstCard = cards.get(firstSelectedIndex);
        Card secondCard = cards.get(secondSelectedIndex);

        if (firstCard.getImageId() == secondCard.getImageId()) {
            score += 10;
            pairsMatched++;
            scoreText.setText("Score: " + score);

            if (pairsMatched == totalPairs) {
                endGame(true); // Win condition
            }
        } else {
            firstCard.setFlipped(false);
            secondCard.setFlipped(false);
        }

        firstSelectedIndex = -1;
        isChecking = false;
        cardAdapter.notifyDataSetChanged();
    }

    private void endGame(boolean won) {
        gameOver = true;
        gameStarted = false;

        if (countDownTimer != null) {
            countDownTimer.cancel(); // Stop the timer
        }

        String message = won ? "🎉 You Win! 🎉" : "⏳ Time's Up! You Lose!";

        new AlertDialog.Builder(this)
                .setTitle("Game Over")
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> finish()) // Return to MainActivity
                .setCancelable(false)
                .show();
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }
}
