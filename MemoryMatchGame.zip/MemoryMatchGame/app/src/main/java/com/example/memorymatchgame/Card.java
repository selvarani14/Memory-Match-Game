package com.example.memorymatchgame;

public class Card {
    private final int imageId;
    private boolean isFlipped;

    public Card(int imageId) {
        this.imageId = imageId;
        this.isFlipped = false;
    }

    public int getImageId() {
        return imageId;
    }

    public boolean isFlipped() {
        return isFlipped;
    }

    public void setFlipped(boolean flipped) {
        isFlipped = flipped;
    }
}
